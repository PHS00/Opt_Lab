package Cap;
import ilog.concert.*;
import ilog.cplex.*;

public class capstone {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		model1();
	}
	
	public static void model1(){
		GetData.main(null);
		int n = GetData.n;
		int K = GetData.K;
		int Q = GetData.Q;
		
		int[][] c = new int [n][n]; //비용
		int[] p = new int[n]; //pickup 개수
		int[] d = new int[n]; //delivery 개수
		//int[] s = new int[n]; //추가 서비스시간
		double[][][] std = new double[n][n][K]; //표준편차
		double[][][] v = new double[n][n][K]; //속력	int -> double 수정
		int[][] D = new int[n][n]; //거리
		
		
		D = GetData.d;
		d = GetData.delivery;
		p = GetData.pickup;
		for(int k=0; k<K; k++) {
			for(int i=0; i<n; i++) {
				for(int j=0; j<n; j++) {
					v[i][j][k] = GetData.speed[i][j];
					std[i][j][k] = GetData.std[i][j];
				}
			}
		}
		for(int i=0; i<n;i++) {
			for(int j=0; j<n; j++) {
				c[i][j] = D[i][j];
			}
		}
		
		// 숫자 설정해야함
		double PI = 1.2816;
		double A = 0;	
		double a = 0.1;
		double[] B = new double[K];
		for(int k = 0; k < K; k++) {
			B[k] = 5000;
		}
		
		try {
			IloCplex cplex = new IloCplex();
			
			//결정변수
			IloNumVar[][][] x = new IloNumVar[n][n][K];
			IloNumVar[][] y = new IloNumVar[n][];
			IloNumVar[][] z = new IloNumVar[n][];
			IloNumVar[] w = new IloNumVar[K];
			IloNumVar[] s = new IloNumVar[K];
			
			for(int i = 0; i<n; i++) {
				for(int j = 0; j<n; j++) {
					x[i][j] = cplex.numVarArray(K, 0, 1, IloNumVarType.Int);
				}
			}
			for(int i=0; i<n; i++) {
				y[i] = cplex.numVarArray(n, 0, Double.MAX_VALUE);	// 1 -> 0 수정
				z[i] = cplex.numVarArray(n, 0, Double.MAX_VALUE);
			}
			for(int i=0; i < K; i++) {
				w[i] = cplex.numVar(0, Double.MAX_VALUE);	// 추가
			}
			int sum=0;
			
			//목적함수
			IloLinearNumExpr objective = cplex.linearNumExpr();
			for(int i=0; i<n; i++) {
				for(int j=0; j<n; j++) {
					for(int k=0; k<K; k++) {
						objective.addTerm(c[i][j], x[i][j][k]);
					}
				}
				//sum+=s[i];
			}
			
			cplex.addMinimize(objective);
			
			
			//제약식
			
			IloLinearNumExpr[] con1 = new IloLinearNumExpr[n];
			IloLinearNumExpr[][] con2 = new IloLinearNumExpr[n][K];
			IloLinearNumExpr[] con3 = new IloLinearNumExpr[K];
			IloLinearNumExpr[][] con4 = new IloLinearNumExpr[n][n];
			IloLinearNumExpr[] con5 = new IloLinearNumExpr[n];
			IloLinearNumExpr[] con6 = new IloLinearNumExpr[n];
			
			IloLinearNumExpr[] con8 = new IloLinearNumExpr[K];
			IloLinearNumExpr[] con9 = new IloLinearNumExpr[K];
			
			
			//con1
			for(int i=0; i<n; i++) {
				con1[i] = cplex.linearNumExpr();
				for(int j=0; j<n; j++) {
					if(i == j) continue;
					for(int k=0; k<K; k++) {
						con1[i].addTerm(1.0, x[i][j][k]);
					}
				}
				cplex.addEq(con1[i], 1);
				
			}
			
			//con2
			for(int i=0; i<n; i++) {
				for(int k=0; k<K; k++) {
					con2[i][k] = cplex.linearNumExpr();
					for(int j=0; j<n; j++) {
						if(i == j) continue;
						con2[i][k].addTerm(1.0, x[i][j][k]);
						con2[i][k].addTerm(-1, x[j][i][k]);
					}
					cplex.addEq(con2[i][k],0);
				}
			}

			
			//con3
			for(int k=0; k<K; k++) {
				con3[k] = cplex.linearNumExpr();
				for(int i=0; i<n; i++) {
					con3[k].addTerm(1.0, x[0][i][k]);
				}
				cplex.addLe(con3[k], 1);	// 수정
			}
			
			//con4
			for(int i=0; i<n; i++) {
				for(int j=0; j<n; j++) {
					if(i==j) continue;
					con4[i][j] = cplex.linearNumExpr();
					for(int k=0; k<K; k++) {
						con4[i][j].addTerm(Q, x[i][j][k]);
					}
					cplex.addLe(cplex.sum(y[i][j],z[i][j]), con4[i][j]);
				}
			}
			
			//con5
			for(int i=0; i<n; i++) {
				con5[i] = cplex.linearNumExpr();
				for(int j=0; j<n; j++) {
					con5[i].addTerm(y[i][j], 1);
					con5[i].addTerm(y[j][i], -1);
				}
				cplex.addEq(con5[i], p[i]);
			}
			
			//con6
			for(int i=0; i<n; i++) {
				con6[i] = cplex.linearNumExpr();
				for(int j=0; j<n; j++) {
					if(i == j) continue;
					con5[i].addTerm(z[i][j], 1);
					con5[i].addTerm(z[j][i], -1);
				}
				cplex.addEq(con6[i], d[i]);
			}
			
			//con7
			IloNumExpr[] con7 = new IloNumExpr[K];	// 수정
			for(int k=0; k<K; k++) {
				con7[k] = cplex.quadNumExpr();
				for(int i=0; i<n; i++) {
					for(int j=0; j<n; j++) {
						if(i == j) continue;
						double tmp = std[i][j][k]*std[i][j][k];
						con7[k] = cplex.sum(con7[k], cplex.prod(tmp, x[i][j][k],x[i][j][k]));
					}
				}
				con7[k] = cplex.sum(con7[k], cplex.prod(-1, w[k],w[k]));
				cplex.addLe(con7[k],0);
			}
			
			//con8, con9
			for(int k=0; k<K; k++) {
				con8[k] = cplex.linearNumExpr();
				con9[k] = cplex.linearNumExpr();
				for(int i=0; i<n; i++) {
					for(int j=0; j<n; j++) {
						if(i == j) continue;
						con8[k].addTerm(D[i][j]/v[i][j][k], x[i][j][k]);
						con9[k].addTerm(a*(d[i]+p[i]), x[j][i][k]);
					}
				}
				cplex.addLe(cplex.sum(con8[k], cplex.prod(PI, w[k])), cplex.sum(B[k], cplex.prod(-1,con9[k])));
			}
			
			//con10
			for(int i=0; i<n; i++) {
				for(int k=0; k<K; k++) {
					cplex.addEq(x[i][i][k], 0);
				}
			}
			
			cplex.solve();
			System.out.println("obj = "+cplex.getObjValue());
			
			
			
		}
		catch(IloException exc) {
			exc.printStackTrace();
		}
	}

}
